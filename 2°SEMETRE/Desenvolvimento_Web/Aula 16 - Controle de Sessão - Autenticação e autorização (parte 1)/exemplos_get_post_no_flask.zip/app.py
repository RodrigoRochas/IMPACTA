from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/formulario')
def formulario():
	nome = request.args.get('nome')
	idade = request.args.get('idade')
	if nome is None or idade is None:
		return render_template('formulario.html')
	else:
		return render_template('recebido.html', nome=nome, idade=idade)

@app.route('/formulario_post', methods=['GET', 'POST'])
def formulario_post():
	nome = request.form.get('nome')
	idade = request.form.get('idade')
	lista_atividades = request.form.getlist('atividades')
	if nome is None or idade is None:
		return render_template('formulario_post.html')
	else:
		return render_template('recebido_post.html', nome=nome, idade=idade,
		atividades=lista_atividades)



app.run(debug=True)
