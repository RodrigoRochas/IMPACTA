const botao = document.getElementById("bt-cor");
const body = document.getElementsByTagName("body")[0];

botao.style.backgroundColor = "rgb(238, 238, 238)";
botao.style.borderWidth = 0;

botao.addEventListener("click", function (){
	let cores = ["rgb(238, 238, 238)", "rgb(250, 195, 195)", "rgb(190, 220, 255)"];
	let cor_atual = botao.style.backgroundColor;
	switch(cor_atual){
		case cores[0]:
			body.style.backgroundColor = cores[1];
			botao.style.backgroundColor = cores[1];
			break;
		case cores[1]:
			body.style.backgroundColor = cores[2];
			botao.style.backgroundColor = cores[2];
			break;
		default:
			body.style.backgroundColor = cores[0];
			botao.style.backgroundColor = cores[0];
	}
	localStorage.setItem("cor-fundo", botao.style.backgroundColor);
});

document.addEventListener("DOMContentLoaded", function (){
	let cor = localStorage.getItem("cor-fundo");
	if (cor){   // testa se a variável cor não é igual a null
		body.style.backgroundColor = cor;
		botao.style.backgroundColor = cor;
	}
});

