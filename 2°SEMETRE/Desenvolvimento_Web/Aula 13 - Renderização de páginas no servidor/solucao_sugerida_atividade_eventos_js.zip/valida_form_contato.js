const tx_nome = document.getElementById("tx-nome");
const tx_email = document.getElementById("tx-email");
const bt_enviar = document.getElementById("bt-enviar");

bt_enviar.addEventListener("click", function (event){
	if (tx_nome.value.trim() == "") {
		alert("O nome não pode ser vazio!");
		event.preventDefault();
	} else if (tx_email.value.trim() == ""){
		alert("O e-mail não pode ser vazio!");
		event.preventDefault();
	}
});
