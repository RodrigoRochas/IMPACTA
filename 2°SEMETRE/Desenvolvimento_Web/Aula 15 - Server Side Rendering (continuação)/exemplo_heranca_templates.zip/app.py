from flask import Flask, render_template

app = Flask(__name__)

@app.route('/pagina1')
def pagina1():
	return render_template('pagina1.html')

@app.route('/pagina2')
def pagina2():
	return render_template('pagina2.html')

@app.route('/pagina3')
def pagina3():
	pessoas = ['João', 'Pedro', 'Maria']
	return render_template('pagina3.html', pessoas=pessoas)

@app.route('/pagina4')
def pagina4():
	return render_template('pagina4.html')

app.run(debug=True)
