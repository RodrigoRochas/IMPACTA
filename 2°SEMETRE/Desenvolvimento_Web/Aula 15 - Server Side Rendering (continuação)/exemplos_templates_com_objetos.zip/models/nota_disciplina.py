class NotaDisciplina:

	def __init__(self, nome_disc, ano, semestre, nota):
		self.__nome_disc = nome_disc
		self.__ano = ano
		self.__semestre = semestre
		self.__nota = nota
	
	def get_nome_disc(self):
		return self.__nome_disc
	
	def get_ano(self):
		return self.__ano

	def get_semestre(self):
		return self.__semestre
	
	def get_nota(self):
		return self.__nota
	
	def get_situacao(self):
		if self.__nota >= 6:
			return 'Aprovado'
		else:
			return 'Reprovado'
	