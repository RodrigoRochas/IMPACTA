from flask import Flask, render_template
from models.nota_disciplina import NotaDisciplina

app = Flask(__name__)

@app.route('/')
def index():
	pessoa = {'nome':'Pedro', 'matricula':987, 'curso':'Engenharia da Computação'}
	disc1 = NotaDisciplina('Linguagem de Programação', 2021, 1, 6.0)
	disc2 = NotaDisciplina('Soft skills', 2021, 1, 3.5)
	disc3 = NotaDisciplina('Desenvolvimento Web', 2021, 2, 10.0)
	disc4 = NotaDisciplina('Programação Orientada a Objetos', 2021, 2, 5.9)
	disc5 = NotaDisciplina('Engenharia de Software', 2022, 1, 8.6)
	notas = [disc1, disc2, disc3, disc4, disc5]
	return render_template('aluno.html', info=pessoa, notas=notas)

app.run(debug=True)
