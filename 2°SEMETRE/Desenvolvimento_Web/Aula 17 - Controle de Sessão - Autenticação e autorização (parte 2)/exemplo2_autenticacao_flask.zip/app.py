from flask import Flask, render_template, request, session, redirect
from models.usuario import BancoDeDados
from datetime import timedelta


app = Flask(__name__)
app.secret_key = 'CHAVE-MUITO-SECRETA'



@app.route('/login', methods=['GET', 'POST'])
def login():
	msg_erro = ''
	if request.method == 'POST':
		usuario = request.form.get('usuario')
		senha = request.form.get('senha')
		bd = BancoDeDados()
		if bd.existe_aluno(usuario, senha):
			session['usuario'] = usuario
			return redirect('/area_logada')
		else:
			msg_erro = 'Usuário ou senha inválidos, tente novamente'
	return render_template('login.html', erro=msg_erro)

@app.route('/area_logada')
def area_logada():
	if 'usuario' in session:
		bd = BancoDeDados()
		dados_aluno = bd.obter_dados(session['usuario'])
		return render_template('area_logada.html', aluno=dados_aluno)
	return redirect('/login')

@app.route('/notas')
def notas():
	if 'usuario' in session:
		bd = BancoDeDados()
		dados_aluno = bd.obter_dados(session['usuario'])
		return render_template('notas.html', aluno=dados_aluno)
	return redirect('/login')

@app.route('/logout')
def sair():
	session.clear()
	return redirect('/login')

app.run(debug=True)
