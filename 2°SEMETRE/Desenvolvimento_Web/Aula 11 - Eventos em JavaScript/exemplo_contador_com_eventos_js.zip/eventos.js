
const btn = document.getElementById("bt-botao");
const div = document.getElementById("div1");

btn.addEventListener("click", function (){
	const paragrafo = document.getElementById("contador");
	let valor = Number(paragrafo.innerText);
	valor++;
	paragrafo.innerText = valor;
});


div.addEventListener("click", function (){
	const paragrafo = document.getElementById("contador");
	let valor = Number(paragrafo.innerText);
	valor--;
	paragrafo.innerText = valor;
});
